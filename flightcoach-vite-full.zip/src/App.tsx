import React from 'react'
import PainelMissao from './components/PainelMissao'

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <PainelMissao />
    </div>
  )
}

export default App
